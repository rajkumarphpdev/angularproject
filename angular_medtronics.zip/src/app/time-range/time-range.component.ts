import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, ElementRef, Input, OnInit } from '@angular/core';
import * as d3 from 'd3';

@Component({
  selector: 'app-time-range',
  templateUrl: './time-range.component.html',
  styleUrl: './time-range.component.scss'
})
export class TimeRangeComponent  implements OnInit,AfterViewInit {
    URL = '../assets/patientInfo.json';
    @Input() chartData:any;

    private svg: any;
    // private margin = { top: 20, right: 20, bottom: 30, left: 40 };
    private margin = 50;

    private width: number =(600 - (this.margin * 2));
    private height: number =(400 - (this.margin * 2));
    data:any = [];
    //  data:any = [
    //     { month: 'mg/Dl', firstItem: this?.chartData['40to70'], salesB: 9, salesC:2}
    //   ];



    constructor(private httpClient: HttpClient ,
                private elementRef: ElementRef
        ){
          
    }
    ngOnInit(): void {
        // this.createSvg();
        // this.drawChart(this.data); // Implement your D3 drawing logic here
     }  
    ngAfterViewInit(): void {
      console.log("chartData" ) ;
      console.log(this.chartData);
      
     this.data = [
        { month: 'mg/Dl', firstItem: this?.chartData['40to70'], secondItem: 
          this?.chartData['70to180']   , thirdItem:this?.chartData['180to240'], 
          fourthItem:this?.chartData['240to400'] }
      ];
      this.createStackedBarChart();
   }
   createStackedBarChart(){
        // Set dimensions and margins
        const margin = { top: 20, right: 30, bottom: 40, left: 50 };
        const width = 200;
        const height = 400;
            // Append SVG
        const svg = d3.select('#stacked-bar-chart-container')
          .append('svg')
          .attr('width', 200)
          .attr('height', height + margin.top + margin.bottom)
          .attr("stroke", "white") // Or your background color
          .attr("stroke-width", 2)
          .append('g')
          .attr('transform', `translate(${margin.left},${margin.top})`);
    
          // Define keys for stacking
          const keys = ['firstItem', 'secondItem', 'thirdItem','fourthItem'];
          
          // Create the stack generator
          const stack = d3.stack().keys(keys);
          const stackedData = stack(this.data);
                    // Scales
          const xScale = d3.scaleBand()
            .domain(this.data.map((d:any) => d.month))
            .range([0, width])
            .padding(0.1)


          const yScale = d3.scaleLinear()
          .domain([0, d3.max(stackedData[stackedData.length - 1], d => d[1]) || 0])
          .range([height, 0]);
        // Colors
        // const color = d3.scaleOrdinal(d3.schemeCategory10);
        const color = d3.scaleOrdinal(d3.schemeCategory10)
                        .domain(["firstItem","secondItem","thirdItem","fourthItem"])
                         .range(["#FF0000", "#8AFF8A", "#FFD68A","#CDAA6D"]);


                        //colour range
      const z = d3.scaleOrdinal(d3.schemeCategory10)
          .range(["#FF0000", "#8AFF8A", "#FFD68A", "#CDAA6D"]); 

        color.domain(keys);
        // Draw bars
            svg.append('g')
              .selectAll('g')
              .data(stackedData)
              .enter().append('g')
              .attr('fill', d => color(d.key))
              .attr('margin','1px')
              .selectAll('rect')
              .data((d:any) => d)
              .enter().append('rect')
              .attr('x', (d:any) => xScale(d.data.month) || 0)
              .attr('y', (d:any) => yScale(d[1]))
              .attr('height', (d:any) => yScale(d[0]) - yScale(d[1]))
              .attr('width', xScale.bandwidth())


              // Add axes
          // svg.append('g')
          //   .attr('transform', `translate(0,${height})`)
          //   .call(d3.axisBottom(xScale));

          // svg.append('g')
          //   .call(d3.axisLeft(yScale));

        const legend = svg.append('g')
        .attr("font-family", "sans-serif")
       .attr("class", "legend")
         .attr("height", "100px")
        //  .attr("transform", "translate(50,10)")
        .attr("font-size", 10)
        .attr("text-anchor", "start")
        .attr('margin','10px')
        .selectAll("g")
        .data(keys) //slice one removes the starting bar
        //.data(keys.slice(1).reverse()) //slice one removes the starting bar
		    .enter().append("g")
        // .attr("transform", 
        //   (d, i) => "translate(0," + (i * 15) + ")"); //loop to spread out E entry vertically
        .attr("transform", 
          (d, i) => "translate(" + (i * 15) + ",20)"); //loop to spread out E entry vertically

        legend.append("rect")
                .attr("y", height) //xPos rect
                .attr("width", 50)
                .attr("height", 19)
                .attr("padding",'10px')
                .attr("fill", z);
                 legend.append("text")
        .attr("x",  50) //xPos text
        .attr("y", height -5)
        .attr("dy", "0.35em")
        .attr('margin','10px')
        .text(d => d);

    
   }

   



}
