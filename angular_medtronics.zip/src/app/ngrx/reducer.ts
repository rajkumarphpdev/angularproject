import { createReducer, on } from '@ngrx/store';
import { updateMyValue } from './actions';
    export interface MyState {
      patientInfo: [];
    }
    export const initialState: MyState = {
      patientInfo: []
    };

    export const myReducer = createReducer(
      initialState,
      on(updateMyValue, (state, { newValue }) => ({ ...state, myProperty: newValue }))
    );
