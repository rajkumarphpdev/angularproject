    import { createAction, props } from '@ngrx/store';

    export const updateMyValue = createAction(
      'patientInformation',
      props<{ newValue: any }>() // Or whatever type your value is
    );
