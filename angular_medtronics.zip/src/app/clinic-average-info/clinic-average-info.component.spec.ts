import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicAverageInfoComponent } from './clinic-average-info.component';

describe('ClinicAverageInfoComponent', () => {
  let component: ClinicAverageInfoComponent;
  let fixture: ComponentFixture<ClinicAverageInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ClinicAverageInfoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ClinicAverageInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
