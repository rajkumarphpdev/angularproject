import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SimpleDataModel } from '../clinic-average-info/clinic-average-info.component';
import { Store } from '@ngrx/store';
import { updateMyValue } from '../ngrx/actions';
import { MyState } from '../ngrx/reducer';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent {
  URL = '../assets/patientInfo.json';
  userIds:any;
  data:any=[];
  patientData:any=[];
  averageData:any=[];
  averagePercent:any=[];
  label:any=['40to70','70to180','180to240','240to400'];
   pieData: SimpleDataModel[] = [
    {
      name: "",
      value: "72"
    },
    {
      name: "",
      value: "23"
    },
    {
      name: "",
      value: "5"
    }
  ];
  constructor(private httpClient: HttpClient,
    private store: Store<MyState>
  ){
    
    this.httpClient.get(this.URL).subscribe((res:any)=>{
       this.userIds = [...new Set(res.map((item:any) => item.userid))];
      for(let i = 0 ;i < this.userIds.length;i++){
         
        let tempData:any=[];
        res.map((response:any)=>{
            if( response.sgvalue != ""){
              if(this.userIds[i].includes(response.userid)){
                tempData.push({response});
              }
            }
        });
        this.data.push(
          {
            userid :this.userIds[i],
            data:tempData
          }
         )

      }
      this.patientData= this.data.filter((filtdata:any)=>{
        return filtdata.data.length >=10
      })
      
      
     this.averageData['40to70']=[];
     this.averageData['70to180']=[];
     this.averageData['180to240']=[];
     this.averageData['240to400']=[];

      if(this.patientData.length >0){
        this.patientData.map((patItem:any)=>{
              patItem.data.map((data:any)=>{
                if(data.response.sgvalue >=40 && data.response.sgvalue < 70 ){
                  this.averageData['40to70'].push(data.response.sgvalue);
                }
                if(data.response.sgvalue >70 && data.response.sgvalue <= 180 ){
                  this.averageData['70to180'].push(data.response.sgvalue);
                }
                if(data.response.sgvalue >180 && data.response.sgvalue <= 240 ){
                  this.averageData['180to240'].push(data.response.sgvalue);
                }
                if(data.response.sgvalue >240 && data.response.sgvalue < 400 ){
                  this.averageData['240to400'].push(data.response.sgvalue);
                }
                   
              })    
          });
      }
      
    });

    console.log(this.averageData);
    for (let j=0;j<this.label.length;j++){
      this.averagePercent[this.label[j]] = this.setChartData(this.averageData,this.label[j]);

    }
    console.log(" this.averagePercent");
    console.log( this.averagePercent);
    this.store.dispatch(updateMyValue({ newValue: this.averagePercent }));

  }

  setChartData(averageData:any,label:any){
        let sum1 = averageData[label].reduce((accumulator:any, currentValue:any) => accumulator + currentValue, 0);
        let p1= (sum1/averageData[label].length).toFixed(2);
        return p1;
  }

  fetchpatientData(months:any){
    // to do api call based on date 
    const endDate = new Date()
    let priorDate;
    switch(months){ 
      case 'one':
        priorDate = new Date().setDate(endDate.getDate() - 30)
        console.log(priorDate);
        break;
      case 'two':
        priorDate = new Date().setDate(endDate.getDate() - 60)
        console.log(priorDate);
        break;
      case 'three':
        priorDate = new Date().setDate(endDate.getDate() - 90)
        console.log(priorDate)
        break;
      default:
        priorDate = new Date().setDate(endDate.getDate() - 30)
        console.log(priorDate)

    
    }

  }
}
