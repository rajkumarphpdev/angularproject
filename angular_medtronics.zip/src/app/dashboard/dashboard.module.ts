import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { TimeRangeComponent } from '../time-range/time-range.component';
import { ClinicAverageInfoComponent } from '../clinic-average-info/clinic-average-info.component';
import { StoreModule } from '@ngrx/store';


@NgModule({
  declarations: [
    DashboardComponent,
    TimeRangeComponent,
    ClinicAverageInfoComponent
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    StoreModule.forRoot({},{})
  ]
})
export class DashboardModule { }
